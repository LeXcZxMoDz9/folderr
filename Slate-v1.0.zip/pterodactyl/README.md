#  dP"8 888           d8 
# C8b Y 888  ,"Y88b  d88    ,e e,
#  Y8b  888 "8" 888 d88888 d88 88b
# b Y8D 888 ,ee 888  888   888   ,
# 8edP  888 "88 888  888    "YeeP"


* Welcome to Slate!
Thank you for purchasing Slate, one of the best admin themes for Pterodactyl, made easy with Blueprint.


* Extension installation.
Before you can start using Slate, you'll need Blueprint. Blueprint allows themes like Slate to have great compatibility with other modifications made by extensions. You can find more information, download links and documentation at https://blueprint.zip.

After you've installed Slate, drag and drop the `slate.blueprint` file over to your Pterodactyl folder (commonly /var/www/pterodactyl) and run `blueprint -install slate`.

If you like the theme please leave a review on the marketplace where you've bought Slate.


* Need help?
You can find my contact information on **prpl.wtf** or (in some cases) you can use the marketplace you've bought Slate to send me a message.