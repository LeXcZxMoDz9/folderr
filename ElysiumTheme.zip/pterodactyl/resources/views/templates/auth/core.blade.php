@extends('templates/wrapper', [
    'css' => ['body' => 'bg-elysium-color1']
])

@section('container')
    <div id="app"></div>
@endsection
